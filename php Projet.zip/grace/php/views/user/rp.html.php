<body>
<style type="text/css">
      nav .a{
        color: #000000;
        text-align: center;
      }
    </style>
<div class="container d-flex hw-100">
    <div class="row align-self-center">
    <nav class="a"><h1 class="a">ESPACE RP</h1></nav>
    </div>

    
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js"></script>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" rel="stylesheet"/>
    <nav class="navbar navbar-toggleable-md navbar-light bg-faded">
    
    <ul class="navbar-nav">
    <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      MENU
    </a>
    <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
        <a class="dropdown-item" href="Ajouter professeur">Ajouter professeur</a>
        <a class="dropdown-item" href="Lister les etudiants">Lister les etudiants</a>
        <a class="dropdown-item" href="Planifier un cours">Planifier un cours</a>
        <a class="dropdown-item" href="Lister les cours">Lister les cours</a>
    </div>
  </li>
</ul>
</nav>
   
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/js/bootstrap.min.js" integrity="sha384-oesi62hOLfzrys4LxRF63OJCXdXDipiYWBnvTl9Y9/TRlw5xlKIEHpNyvvDShgf/" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/chartist.js/latest/chartist.min.js"></script>
    <!-- Github buttons -->
   
</body>