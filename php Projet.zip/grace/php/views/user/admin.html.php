 <li class="nav-item">
                    <a class="nav-link" href="<?php path('user/admin') ?>">Ajouter un RP</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php path('security/deleteRp') ?>">Supprimer un RP</a>
                <li class="nav-item">
                    <a class="nav-link" href="<?php path('security/updateRp') ?>">Modifier un RP</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php path('security/addAc') ?>">Ajouter un AC</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php path('security/deleteAc') ?>">Supprimer un AC</a>
                <li class="nav-item">
                    <a class="nav-link" href="<?php path('security/updateAc') ?>">Modifier un AC</a>
                </li>

  <nav class="navbar navbar-toggleable-md navbar-light bg-faded">
    
    <ul class="navbar-nav">
    <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      MENU
    </a>
    <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
      <a class="dropdown-item" href="Ajouter un RP ou AC">Ajouter un RP ou AC</a>
      <a class="dropdown-item" href="Modifier un RP ou AC">Modifier un RP ou AC</a>
      <a class="dropdown-item" href="Supprimer un RP ou AC">Supprimer un RP ou AC</a>
    </div>
  </li>
</ul>
</nav>