-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : jeu. 24 juin 2021 à 08:39
-- Version du serveur :  5.7.31
-- Version de PHP : 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `gestion_des_etudiants`
--

-- --------------------------------------------------------

--
-- Structure de la table `absence`
--

DROP TABLE IF EXISTS `absence`;
CREATE TABLE IF NOT EXISTS `absence` (
  `idAbscence` varchar(10) NOT NULL,
  `dateAbscence` date NOT NULL,
  `matriculeEtu` varchar(255) NOT NULL,
  `coursId` varchar(100) NOT NULL,
  PRIMARY KEY (`idAbscence`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `absence`
--

INSERT INTO `absence` (`idAbscence`, `dateAbscence`, `matriculeEtu`, `coursId`) VALUES
('AAA-AAA-AA', '2021-05-18', '', 'EEE-EEE-EEE');

-- --------------------------------------------------------

--
-- Structure de la table `classe`
--

DROP TABLE IF EXISTS `classe`;
CREATE TABLE IF NOT EXISTS `classe` (
  `libelleClass` varchar(100) NOT NULL,
  `niveauClass` varchar(10) NOT NULL,
  `filiereClass` varchar(100) NOT NULL,
  PRIMARY KEY (`libelleClass`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `classe`
--

INSERT INTO `classe` (`libelleClass`, `niveauClass`, `filiereClass`) VALUES
('maths', 'L2', 'Maths');

-- --------------------------------------------------------

--
-- Structure de la table `cours`
--

DROP TABLE IF EXISTS `cours`;
CREATE TABLE IF NOT EXISTS `cours` (
  `idCours` int(100) NOT NULL AUTO_INCREMENT,
  `dateCours` date NOT NULL,
  `libelletCours` varchar(100) NOT NULL,
  `matriculeProf` varchar(100) NOT NULL,
  `libelleModule` varchar(100) NOT NULL,
  `semestreCours` varchar(100) NOT NULL,
  `nbrHeureCours` int(10) NOT NULL,
  `heureDebutCours` time NOT NULL,
  `heureFinCours` time NOT NULL,
  PRIMARY KEY (`idCours`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `etudiant`
--

DROP TABLE IF EXISTS `etudiant`;
CREATE TABLE IF NOT EXISTS `etudiant` (
  `idEtu` int(11) NOT NULL AUTO_INCREMENT,
  `matriculeEtu` varchar(100) NOT NULL,
  `nomEtu` varchar(25) NOT NULL,
  `prenomEtu` varchar(25) NOT NULL,
  `dateNaissanceEtu` date NOT NULL,
  `sexeEtu` varchar(10) NOT NULL,
  `classeEtu` varchar(25) NOT NULL,
  `competenceEtu` varchar(255) NOT NULL,
  `avatarEtu` varchar(100) NOT NULL,
  `parcoursEtu` varchar(255) NOT NULL,
  PRIMARY KEY (`idEtu`),
  UNIQUE KEY `matriculeEtu` (`matriculeEtu`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `etudiant`
--

INSERT INTO `etudiant` (`idEtu`, `matriculeEtu`, `nomEtu`, `prenomEtu`, `dateNaissanceEtu`, `sexeEtu`, `classeEtu`, `competenceEtu`, `avatarEtu`, `parcoursEtu`) VALUES
(1, 'LLL-LLL-LLL', 'Yameogo', 'Ivan', '2005-05-20', 'm', 'L1 web developper', 'integration web', 'photo', 'Ingenieur'),
(2, 'MMM-MMM-MMM', 'Mbaye', 'Arame', '2000-09-27', 'f', 'L1 web marketing', 'designer', 'photo', 'Marketer'),
(3, 'NNN-NNN-NNN', 'Dibert-Dollet', 'Jean-Paul', '2000-05-04', 'm', 'L1 web player', 'playing', 'photo', 'ceinture arc-en-ciel');

-- --------------------------------------------------------

--
-- Structure de la table `module`
--

DROP TABLE IF EXISTS `module`;
CREATE TABLE IF NOT EXISTS `module` (
  `libelleModule` varchar(100) NOT NULL,
  PRIMARY KEY (`libelleModule`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `module`
--

INSERT INTO `module` (`libelleModule`) VALUES
('economie'),
('Maths');

-- --------------------------------------------------------

--
-- Structure de la table `professeur`
--

DROP TABLE IF EXISTS `professeur`;
CREATE TABLE IF NOT EXISTS `professeur` (
  `matriculeProf` varchar(100) NOT NULL,
  `nomProf` varchar(100) NOT NULL,
  `prenomProf` varchar(100) NOT NULL,
  `dateNaissanceProf` date NOT NULL,
  `sexeProf` varchar(100) NOT NULL,
  `gradeProf` varchar(100) NOT NULL,
  `classeProf` varchar(100) NOT NULL,
  `moduleProf` varchar(100) NOT NULL,
  `avatarProf` varchar(100) NOT NULL,
  `idProf` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idProf`),
  UNIQUE KEY `matriculeProf` (`matriculeProf`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `professeur`
--

INSERT INTO `professeur` (`matriculeProf`, `nomProf`, `prenomProf`, `dateNaissanceProf`, `sexeProf`, `gradeProf`, `classeProf`, `moduleProf`, `avatarProf`, `idProf`) VALUES
('PPP-PPP-PPP', 'Olafa', 'Divine', '2000-12-26', 'f', 'Doctor', 'Actuariat', 'Maths', 'photo', 1),
('QQQ-QQQ-QQQ', 'Adaisso', 'Hugues', '2000-04-21', 'm', 'Professeur', 'monnaie', 'economie', 'photo', 2);

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
CREATE TABLE IF NOT EXISTS `utilisateur` (
  `login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `loginUser` (`login`),
  UNIQUE KEY `1` (`login`),
  UNIQUE KEY `login` (`login`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`login`, `password`, `role`, `id`, `nom`, `avatar`) VALUES
('Babou@gmail.com', '$2y$10$6Kvv6O4aC39HB97OuWz4AezGLCKyIaIPQonhQd6AuGlk8P2V9EOUW', 'Admin', 1, 'BABOU', 'Babou@gmail.com');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
